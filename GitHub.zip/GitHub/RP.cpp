
#include <ilcplex/ilocplex.h>
#include <sstream>
#include <stdio.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <math.h>
#include <string.h>

using namespace std;
struct Instancia {
    int nI;
    int nJ;
    int nK;
    int nL;
    vector<vector<int> > Ij;
    vector<vector<int> > Jk;
    vector<vector<int> > Kj;
    vector<vector<int> > Kl;
    vector<vector<int> > Lk;
    vector<vector<int> > Ji;

    vector<vector<int> > a;
    vector<vector<vector<double> > > b;
    vector<vector<int> > c;
    vector<vector<double> > s;
    vector<double> p;
    vector<double> d;
    vector<double> f;
   
    vector<vector<vector<int> > > x;
  	vector<int> w;
    vector<vector<int> > y;

};


ILOSTLBEGIN
//cplex.setParam( IloCplex::MIPEmphasis, MIPEMPH);
typedef IloArray<IloNumVar> arrayvar;
typedef IloArray<IloNumVarArray> NumVarMatrix;
typedef IloArray<NumVarMatrix> NumVarMatrix3;

int main(int argc, const char * argv[]) {
 
    vector< vector<float> > M;
    Instancia Ins;
    int i, j, k, l, w;
    
    string nombreIns = argv[1];
    ifstream lee;
    lee.open( nombreIns.c_str() );
    if(lee.fail())
        cout << "Error al abrir archivos de lectura!!" << endl;
    
    cout << endl<<nombreIns<<endl;
    
    lee >> Ins.nI;
    lee >> Ins.nJ;
    lee >> Ins.nK;
    lee >> Ins.nL;


    Ins.Kj.resize(Ins.nJ);
    Ins.c.resize(Ins.nJ);
    for (int j = 0; j < Ins.nJ; j ++) {
        Ins.c[j].resize(Ins.nK);
        for (int k = 0; k < Ins.nK; k ++){
                lee >> Ins.c[j][k];
            if(Ins.c[j][k] > 0){
               Ins.Kj[j].push_back(k);
            }
        }
    }
    
    Ins.Jk.resize(Ins.nK);
    for(k=0;k<Ins.nK;k++){
        for(j=0; j<Ins.nJ;j++){
            if(Ins.c[j][k] > 0){
                Ins.Jk[k].push_back(j);
            }
        }
    }
    
    Ins.Ji.resize(Ins.nI);
    Ins.a.resize(Ins.nI);
    for (int i = 0; i < Ins.nI ; i ++){
        Ins.a[i].resize(Ins.nJ);
        for (int j = 0; j < Ins.nJ; j ++){
            lee >> Ins.a[i][j];
            if(Ins.a[i][j] > 0){
               Ins.Ji[i].push_back(j);
            }
        }
    }
    
    Ins.Ij.resize(Ins.nJ);
    for(int j=0;j<Ins.nJ;j++){
        for(int i=0;i<Ins.nI;i++){
            if(Ins.a[i][j]>0)
                Ins.Ij[j].push_back(i);
        }
    }

    Ins.Lk.resize(Ins.nK);
    Ins.s.resize(Ins.nK);
    for (k = 0; k < Ins.nK; k ++) {
        Ins.s[k].resize(Ins.nL);
        for (l = 0; l < Ins.nL; l ++)
        { lee >> Ins.s[k][l];
            if(Ins.s[k][l] > 0){
                Ins.Lk[k].push_back(l);
            }
        }
    }
    
    Ins.Kl.resize(Ins.nL);
    for(l=0;l<Ins.nL;l++){
        for(int k=0;k<Ins.nK;k++){
            if(Ins.s[k][l]>0)
                Ins.Kl[l].push_back(k);
        }
    }

    Ins.b.resize(Ins.nJ);
    for (int j = 0; j < Ins.nJ; j++) {
        Ins.b[j].resize(Ins.nK);
        for (int k = 0; k < Ins.nK; k++){
            Ins.b[j][k].resize(Ins.nL);
            for (int l = 0; l < Ins.nL; l++){
                lee >> Ins.b[j][k][l];
            }
        }
    }
    
    Ins.p.resize(Ins.nI);
    for(int i = 0; i < Ins.nI; i ++){
        lee >> Ins.p[i];
    }
    
    Ins.d.resize(Ins.nI);
    for(int i = 0; i < Ins.nI; i ++){
        lee >> Ins.d[i];
    }
    
    Ins.f.resize(Ins.nL);
    for(l = 0; l < Ins.nL; l++){
        lee >>Ins.f[l];
    }
              float auxm;
        M.resize(Ins.nK);
        for (k=0; k<Ins.nK; k++) {
            M[k].resize(Ins.nL);
            for (l=0; l<Ins.Lk[k].size(); l++) {
                auxm = 10000;
                for (j=0; j<Ins.Jk[k].size(); j++) {
                    if (auxm>Ins.b[Ins.Jk[k][j]][k][Ins.Lk[k][l]]) {
                        auxm =Ins.b[Ins.Jk[k][j]][k][Ins.Lk[k][l]];
                    }
                }
                M[k][Ins.Lk[k][l]]= Ins.f[Ins.Lk[k][l]]/auxm;
              
            }
          
        }

    string Slots = "Slot_" + nombreIns;
    cout<<Slots<<endl;
 
    ifstream lee2;
    lee2.open( Slots.c_str() );
    if(lee2.fail())
        cout << "Error al abrir archivos de lectura!!" << endl;


    double cotaDual, cotaPrimal;
    lee2>>cotaDual;
    lee2>>cotaPrimal;

    Ins.w.resize(Ins.nI);
    for (i=0; i<Ins.nI; i++) {
        lee2>>Ins.w[i];
    }
    
    Ins.y.resize(Ins.nK);
    for (k=0; k<Ins.nK; k++) {
        Ins.y[k].resize(Ins.nL);
        for (l=0; l<Ins.nL; l++) {
            lee2>>Ins.y[k][l];
        }
    }
    
    Ins.x.resize(Ins.nJ);
    for (j=0; j<Ins.nJ; j++){
        Ins.x[j].resize(Ins.nK);
        for (k=0; k<Ins.nK; k++) {
            Ins.x[j][k].resize(Ins.nL);
            for (l=0; l<Ins.nL; l++) {
                lee2>>Ins.x[j][k][l];
            }
        }
    }
    

        double time_limit = 3600;
        double gap_limit = 0.03; //0.01 es 1% de relative gap
        IloEnv env;
        
        try {
            
            NumVarMatrix3 u(env,Ins.nJ);
            for( j = 0; j < Ins.nJ; j ++){
               u[j] = NumVarMatrix (env, Ins.nK);
                for (k=0 ; k<Ins.nK; k++) {
                    u[j][k] = IloNumVarArray(env, Ins.nL, 0, 100000000, ILOINT);
                }
            }
            
            NumVarMatrix v(env, Ins.nK);
            for(int i = 0; i < Ins.nK; i ++){
                v[i] = IloNumVarArray(env, Ins.nL, 0, 100000, ILOFLOAT);
            }
            
            IloNumVarArray wb(env, Ins.nI, 0, 100000000, ILOINT);
            
            NumVarMatrix yb(env, Ins.nK);
            for(int i = 0; i < Ins.nK; i ++){
                yb[i] = IloNumVarArray(env, Ins.nL, 0, 1, ILOINT);
            }
            
            NumVarMatrix3 zL(env,Ins.nK);
            for(int j = 0; j < Ins.nK; j ++){
                zL[j] = NumVarMatrix (env, Ins.nK);
                for(int k=0 ; k<Ins.nK; k++) {
                    zL[j][k] = IloNumVarArray(env, Ins.nL, 0, 1, ILOINT);
                    for(int l = 0; l < Ins.nL; l ++)
                        zL[j][k][l].setUB( Ins.s[j][l]*Ins.s[k][l] );
                }
            }
            
            NumVarMatrix3 zK(env,Ins.nL);
            for(int l = 0; l < Ins.nL; l ++){
                zK[l] = NumVarMatrix (env, Ins.nL);
                for(int l1 = 0 ; l1 < Ins.nL; l1 ++) {
                    zK[l][l1] = IloNumVarArray(env, Ins.nK, 0, 1, ILOINT);
                    for(int k = 0; k < Ins.nK; k ++)
                        zK[l][l1][k].setUB( Ins.s[k][l]*Ins.s[k][l1] );
                }
            }
            
            IloModel modelo(env);
            IloExpr SumVaru(env);
            IloExpr SumVarx(env);
            IloExpr SumVar(env);
    
            for (i=0; i<Ins.nI; i++) {
                modelo.add(wb[i]<=Ins.d[i]); //NUEVA RETRICCI�N CON DEMANDA// restricci�n (6)_V5
            }
            
            SumVaru.clear();
            SumVarx.clear();
            for (k=0; k<Ins.nK; k++) {
                for (l=0; l<Ins.Lk[k].size(); l++) {
                    
                    for (j = 0; j < Ins.Jk[k].size(); j ++) {
                    
                            SumVaru += u[Ins.Jk[k][j]][k][Ins.Lk[k][l]];
                            SumVarx += Ins.x[Ins.Jk[k][j]][k][Ins.Lk[k][l]];
                      
                    }
                
                    modelo.add( yb[k][Ins.Lk[k][l]] <= SumVaru ); // restricci�n (5)_V5
                    
                    modelo.add(SumVaru <= SumVarx*yb[k][Ins.Lk[k][l]] ); //restriccion (19)_V5
                    
                    SumVaru.clear();
                    SumVarx.clear();
                 
                }
            }

           
            
            SumVarx.clear();
            SumVar.clear();
            for (int j=0; j<Ins.nJ; j++) {
                
                for (int i=0; i<Ins.Ij[j].size(); i++) {
                    SumVarx = SumVarx  + Ins.a[Ins.Ij[j][i]][j]*wb[Ins.Ij[j][i]];
                }
                
                
                for (int k=0; k<Ins.Kj[j].size(); k++) {
                    for (int l=0; l<Ins.Lk[Ins.Kj[j][k]].size(); l++) {
                        SumVar = SumVar + u[j][Ins.Kj[j][k]][Ins.Lk[Ins.Kj[j][k]][l]]*Ins.c[j][Ins.Kj[j][k]];
                    }
                }
                
                modelo.add(SumVarx <= SumVar); //RESTRICCI�N (7)_V5
                SumVarx.clear();
                SumVar.clear();
                
            }
            
            for (l=0;l<Ins.nL ; l++ ) {
                
                for (k=0; k<Ins.Kl[l].size(); k++) {
                    
                    for (int kp=0; kp<Ins.Kl[l].size(); kp++) {
                        
                        if(Ins.Kl[l][k] != Ins.Kl[l][kp] ){
                            modelo.add(2-yb[Ins.Kl[l][k]][l]-yb[Ins.Kl[l][kp]][l]+zL[Ins.Kl[l][k]][Ins.Kl[l][kp]][l]+zL[Ins.Kl[l][kp]][Ins.Kl[l][k]][l] >= (1)); //RESTRICCI�N (14)_V5
                        
                            modelo.add(zL[Ins.Kl[l][k]][Ins.Kl[l][kp]][l]+zL[Ins.Kl[l][kp]][Ins.Kl[l][k]][l] <= (1)); //RESTRICCI�N (15)_V5
                        }
                    }
                }
            }
            
            SumVar.clear();
            SumVarx.clear();
            for (l=0; l<Ins.nL; l++) {
                for (k=0; k<Ins.Kl[l].size(); k++) {
                    
                    for (int kp=0; kp<Ins.Kl[l].size(); kp++) {
                        SumVar += zL[Ins.Kl[l][kp]][Ins.Kl[l][k]][l];
                        SumVarx += zL[Ins.Kl[l][k]][Ins.Kl[l][kp]][l];
                    }
                    int nk1 = Ins.Kl[l].size();
                    stringstream nombre;
                    //[XX]: Restricciones (16) y (17)
                    modelo.add (SumVar <= yb[Ins.Kl[l][k]][l]*(nk1 - 1)); ////RESTRICCI�N (16)_V5
                    modelo.add (SumVarx <= yb[Ins.Kl[l][k]][l]*(nk1 - 1)); //RESTRICCI�N (17)_V5*/
                    
                    /*/[XX]: SUMA RECOMENDADA POR REVISOR
                    nombre<<"Cota 1y2" <<"["<<l<<","<<Ins.Kl[l][k];
                    modelo.add (SumVar + SumVarx <= yb[Ins.Kl[l][k]][l]*(nk1 - 1)).setName( nombre.str().c_str() ); //restriccion (16)y(17)_v5*/
                    
                    SumVar.clear();
                    SumVarx.clear();
                }
            }
            
            SumVar.clear();
            SumVarx.clear();
            for (l=0; l<Ins.nL; l++) {
                for (k=0; k<Ins.Kl[l].size(); k++) {
                    
                    for (j=0; j<Ins.Jk[Ins.Kl[l][k]].size(); j++) {
                        SumVar+= u[Ins.Jk[Ins.Kl[l][k]][j]][Ins.Kl[l][k]][l]*Ins.b[Ins.Jk[Ins.Kl[l][k]][j]][Ins.Kl[l][k]][l];
                    }
                    
                    for (int kp=0; kp<Ins.Kl[l].size(); kp++) {
                        
                        if (Ins.Kl[l][k] != Ins.Kl[l][kp] ) {
                        
                        for (j=0; j<Ins.Jk[Ins.Kl[l][kp]].size(); j++) {
                            SumVarx+= u[Ins.Jk[Ins.Kl[l][kp]][j]][Ins.Kl[l][kp]][l]*Ins.b[Ins.Jk[Ins.Kl[l][kp]][j]][Ins.Kl[l][kp]][l];
                        }
                        
                        modelo.add (v[Ins.Kl[l][k]][l] + SumVar + Ins.s[Ins.Kl[l][k]][l]*yb[Ins.Kl[l][k]][l] <= v[Ins.Kl[l][kp]][l] + Ins.f[l]*(1-zL[Ins.Kl[l][k]][Ins.Kl[l][kp]][l]));//RESTRICCI�N (18)_V5
                        
                         modelo.add (v[Ins.Kl[l][kp]][l] + SumVarx + Ins.s[Ins.Kl[l][kp]][l]*yb[Ins.Kl[l][kp]][l]  <= v[Ins.Kl[l][k]][l] + Ins.f[l]*(1-zL[Ins.Kl[l][kp]][Ins.Kl[l][k]][l])); //RESTRICCI�N (18)_V5
                            
                        

                        SumVarx.clear();
                        
                        }
                        
                    }
                    
                    SumVar.clear();

                }
            }
    
            for(k=0;k<Ins.nK ; k++ ) {
                for(l=0; l<Ins.Lk[k].size(); l++) {
                    for(int lp = 0; lp < Ins.Lk[k].size(); lp++){
                        if( l != lp ){
                           
                            modelo.add(2 - yb[k][Ins.Lk[k][l]] - yb[k][Ins.Lk[k][lp]] + zK[ Ins.Lk[k][l] ][ Ins.Lk[k][lp] ][k] + zK[ Ins.Lk[k][lp] ][ Ins.Lk[k][l] ][k] >= 1); ////RESTRICCI�N (9)_V5
                            
                            modelo.add(zK[Ins.Lk[k][l]][Ins.Lk[k][lp]][k] + zK[Ins.Lk[k][lp]][Ins.Lk[k][l]][k] <= 1); //RESTRICCI�N (10)_V5
                          
                        }
                    }
                }
            }
  
            SumVar.clear();
            SumVarx.clear();
            for (k=0; k<Ins.nK; k++) {
                for (l=0; l<Ins.Lk[k].size(); l++) {
                    for (int lp=0; lp<Ins.Lk[k].size(); lp++) {
                        SumVar += zK[Ins.Lk[k][lp]][Ins.Lk[k][l]][k];
                        SumVarx += zK[Ins.Lk[k][l]][Ins.Lk[k][lp]][k];
                    }
                    int nl1 = Ins.Lk[k].size();
                    stringstream nombre;
                    //[XX]: Restricciones (11) y (12)
                    modelo.add (SumVar <= yb[k][Ins.Lk[k][l]]*(nl1 - 1)); //RESTRICCI�N (11)_V5
                    modelo.add (SumVarx <= yb[k][Ins.Lk[k][l]]*(nl1 - 1)); //RESTRICCI�N (12)_V5*/
                    
                    /*/[XX]: SUMA RECOMENDADA POR REVIEWER
                    nombre << "Entre maquinas 1y2"<<k<<","<<Ins.Lk[k][l]<<" ,";
                    modelo.add (SumVar + SumVarx <= yb[k][Ins.Lk[k][l]]*(nl1 - 1)).setName( nombre.str().c_str() ); //restriccion (11)y(12)_v5*/
                    
                    SumVar.clear();
                    SumVarx.clear();
                }
            }
           
            int maxf = 0 ;
            for (l=0; l<Ins.nL; l++) {
                if (Ins.f[l]>maxf) {
                    maxf = Ins.f[l];
                }
            }
            
            SumVar.clear();
            SumVarx.clear();
            for (k=0; k<Ins.nK; k++) {
                for (l=0; l<Ins.Lk[k].size(); l++) {
                    for (j=0; j<Ins.Jk[k].size(); j++) {
                        SumVar+= u[Ins.Jk[k][j]][k][Ins.Lk[k][l]]*Ins.b[Ins.Jk[k][j]][k][Ins.Lk[k][l]];
                    }
                    
                    for (int lp=0; lp<Ins.Lk[k].size(); lp++) {
                        
                        if (Ins.Lk[k][l] != Ins.Lk[k][lp] ) {
                            
                            for (j=0; j<Ins.Jk[k].size(); j++) {
                                SumVarx+= u[Ins.Jk[k][j]][k][Ins.Lk[k][lp]]*Ins.b[Ins.Jk[k][j]][k][Ins.Lk[k][lp]];
                            }
                            
                            modelo.add (v[k][Ins.Lk[k][l]] + SumVar + Ins.s[k][Ins.Lk[k][l]] * yb[k][Ins.Lk[k][l]] <= v[k][Ins.Lk[k][lp]] + maxf*(1-zK[Ins.Lk[k][l]][Ins.Lk[k][lp]][k])); //RESTRICCI�N (13)_V5
                            
                           modelo.add (v[k][Ins.Lk[k][lp]] + SumVarx + Ins.s[k][Ins.Lk[k][lp]]* yb[k][Ins.Lk[k][l]] <= v[k][Ins.Lk[k][l]] + maxf*(1-zK[Ins.Lk[k][lp]][Ins.Lk[k][l]][k]));  //RESTRICCI�N (13)_V5
                            SumVarx.clear();
                        }
                    }
                    SumVar.clear();
                    
                }
            }
            
            for (l=0; l<Ins.nL ; l++) {
                for (k=0; k<Ins.nK; k++) {
                     IloExpr SumVar(env);
                    for (j=0; j<Ins.Jk[k].size(); j++) {
                        SumVar+= u[Ins.Jk[k][j]][k][l]*Ins.b[Ins.Jk[k][j]][k][l];
                    }
                    
                    modelo.add (v[k][l] + SumVar <= (Ins.f[l] - Ins.s[k][l])*yb[k][l]); //RESTRICCI�N (8)v2_V5
                    
                    SumVar.clear();
                    
                    for (j=0; j<Ins.nJ; j++) {
                        modelo.add(u[j][k][l] <= Ins.x[j][k][l]); //RESTRICCI�N (20)_V5
                    }
                
                    modelo.add(yb[k][l] <= Ins.y[k][l]); //RESTRICCI�N (21)_V5
                    
                }
            }
            
            
            for (int k=0; k<Ins.nK; k++) {
                for (int l=0; l<Ins.nL; l++) {
                    for (int lp=0; lp<Ins.nL; lp++) {
                        if(lp!=l){
                            modelo.add(zK[l][lp][k]<=Ins.s[k][l]);
                            modelo.add(zK[l][lp][k]<=Ins.s[k][lp]);
                            modelo.add(zK[lp][l][k]<=Ins.s[k][l]);
                            modelo.add(zK[lp][l][k]<=Ins.s[k][lp]);
                        }else{
                            modelo.add(zK[l][lp][k]==0);
                            modelo.add(zK[lp][l][k]==0);
                        }
                        
                    }
                }
            }
            
            for (int l=0; l<Ins.nL; l++) {
                for (int k=0; k<Ins.nK; k++) {
                    for (int kp=0; kp<Ins.nK; kp++) {
                        if (kp!=k) {
                            modelo.add(zL[k][kp][l]<=Ins.s[k][l]);
                            modelo.add(zL[k][kp][l]<=Ins.s[kp][l]);
                            modelo.add(zL[kp][k][l]<=Ins.s[k][l]);
                            modelo.add(zL[kp][k][l]<=Ins.s[kp][l]);
                        }else{
                            modelo.add(zL[k][kp][l]==0);
                            modelo.add(zL[kp][k][l]==0);
                        }
                    }
                }
            }

            
            cout << "Definiendo funcion objetivo... " << endl;
            IloExpr OBJ(env);
            for( i = 0; i < Ins.nI; i ++)
                OBJ += Ins.p[i] * wb[i];

            cout << "Building model for cplex ..." << endl;
            IloCplex cplex(env);
            IloObjective Objetivo = IloMaximize( env, OBJ );
            modelo.add(Objetivo);
            
            cplex.setParam( IloCplex::ClockType, 2 );
            cplex.setParam( IloCplex::TiLim, time_limit );
            cplex.setParam( IloCplex::EpGap, gap_limit );
            //cplex.setOut( env.getNullStream() );
            //cplex.setParam( IloCplex::HeurFreq, heuristics );
            //cplex.setParam( IloCplex::RINSHeur, heuristics );
            //cplex.setParam( IloCplex::MIPEmphasis, MIPEMPH);
            
            cplex.extract(modelo);
            double itime = cplex.getCplexTime();
            cout << "Model extracted for cplex thus, solving ..." << endl;
            cplex.solve();
            double tiempo = cplex.getCplexTime() - itime;
            cout << "CPLEX SATUS == " << cplex.getCplexStatus() << endl; //IMPRIMIR SI ES INFACTIBLE
 
            vector< vector < vector <float> > > vf;
            vf.resize(Ins.nK);
            float Sum=0;
            for (k =0; k<Ins.nK; k++) {
                vf[k].resize(Ins.nL);
                for (l =0; l<Ins.nL; l++) {
                    vf[k][l].resize(2);
                    vf[k][l][0]= cplex.getValue(v[k][l])*100;
                    int a=vf[k][l][0];
                    vf[k][l][0] = (double)a/100;
                    for (j=0; j<Ins.nJ; j++) {
                        Sum+= (int)(cplex.getValue(u[j][k][l])+.1)*Ins.b[j][k][l];
                    }
                    Sum += Ins.s[k][l]*(int)(cplex.getValue(yb[k][l])+.1)+vf[k][l][0];
                    vf[k][l][1]= Sum*100;
                    a =vf[k][l][1];
                    vf[k][l][1] = (double)a/100;
                  //  vf[k][l][1]=floorf(vf[k][l][1] * 100) / 100;
                    cout<<" El molde "<<k <<" se instalo en maquina "<<l<< "en tiempo "<< "["<<vf[k][l][0]<<"-"<<vf[k][l][1]<<"]"<<endl;
                   // salida<<" El molde "<<k <<" se instalo en maquina "<<l<< "en tiempo "<< "["<<vf[k][l][0]<<"-"<<vf[k][l][1]<<"]"<<endl;
                    Sum = 0;
                }
            }
            
         
            int contador=0;
            for (j=0; j<Ins.nJ; j++) {
                for (k=0; k<Ins.nK; k++) {
                    for (l=0; l<Ins.nL; l++) {
                        if ((int)(cplex.getValue(yb[k][l])+.1)==0 and (int)(cplex.getValue(u[j][k][l])+.1)>0) {
                            contador++;
                        }
                    }
                }
            }
            
            for (int k=0; k<Ins.nK; k++) {
                for (int l=0; l<Ins.nL;l++ ) {
                    if ((int)(cplex.getValue(yb[k][l])+.1)==1) {
                        
                        for (int lp=0; lp<Ins.nL; lp++) {
                            if (cplex.getValue(yb[k][lp])==1 && l!=lp) {
                                bool c1 = vf[k][l][0]<=vf[k][lp][0] and vf[k][l][1]>= vf[k][lp][1];
                                bool c2 = vf[k][l][0]>vf[k][lp][0] and vf[k][l][1]>vf[k][lp][1]  and vf[k][l][0]< vf[k][lp][1];
                                bool c4 = vf[k][l][0]>=vf[k][lp][0] and vf[k][l][1]<= vf[k][lp][1];
                                bool c3 = vf[k][l][1]< vf[k][lp][1] and vf[k][l][0]<vf[k][lp][0] and vf[k][lp][0]<vf[k][l][1];
                                if (c1 or c2 or c3 or c4) {
                                   contador++;
                                    
                                }
                            }
                        }
                    }
                }
            }
      
            for (int l=0 ; l<Ins.nL; l++) {
                for (int k=0; k<Ins.Kl[l].size(); k++) {
                    int m = Ins.Kl[l][k];
                    if (cplex.getValue(yb[m][l])==1) {
                        for (int kp=0; kp<Ins.Kl[l].size(); kp++) {
                            int mp = Ins.Kl[l][kp];
                            if (cplex.getValue(yb[mp][l]) == 1 and mp!=m) {
                                bool c1 = vf[m][l][0]<=vf[mp][l][0] and vf[m][l][1]>= vf[mp][l][1];
                                bool c4 = vf[m][l][0]>=vf[mp][l][0] and vf[m][l][1]<= vf[mp][l][1];
                                bool c2 = vf[m][l][0]>vf[mp][l][0] and vf[m][l][1]> vf[mp][l][1]  and vf[m][l][0]< vf[mp][l][1];
                                bool c3 = vf[m][l][1]< vf[mp][l][1] and vf[m][l][0]<vf[mp][l][0] and vf[mp][l][0]<vf[m][l][1];
                                if (c1 or c2 or c3 or c4) {
                                    contador++;
                                }
                            }
                        }
                    }
                    
                }
            }
            
           int  piezasNec = 0 ;
           int  piezasHec = 0 ;
            for (j=0; j<Ins.nJ; j++) {
                
                for ( int i=0; i<Ins.nI; i++) {
                    piezasNec += (int)(cplex.getValue(wb[i])+.1)*Ins.a[i][j];
                }
                for (k=0; k<Ins.nK; k++) {
                    for (l=0; l<Ins.nL; l++) {
                        
                        piezasHec+= (int)(cplex.getValue(u[j][k][l])+0.1)*Ins.c[j][k];

                    }
                }
                    
                if(piezasHec < piezasNec) {
                    contador++;
                }
                
                piezasHec = 0;
                piezasNec = 0;
                
            }
         
            if (contador>0) {
                ofstream salida;
                salida.open( "InFactible.txt", ios::app );
                salida << nombreIns<<endl;
                salida.close();
            }
                ofstream salida;
                salida.open( "LOG_RP.txt", ios::app );
                salida << nombreIns << "\t" << cplex.getBestObjValue() << "\t" << cplex.getObjValue() << "\t" << tiempo << endl;
                salida.close();
                
                stringstream FileName;
                FileName << "Sol_RP_" <<nombreIns;
                salida.open( FileName.str().c_str() );
                salida << fixed;
                salida.precision(2);
                
                cout << "Mejor cota dual == " << cplex.getBestObjValue() << endl;
                cout << "Mejor cota primal == " << cplex.getObjValue() << endl;
                salida<<endl;
            
                for (i = 0; i < Ins.nI; i ++){
                    salida <<"\t "<< (int)(cplex.getValue(wb[i])+0.1) << endl;
                }
                salida<<endl;
            
                for (k = 0; k < Ins.nK; k ++){
                    for (l=0; l<Ins.nL; l++) {
                        salida <<(int)(cplex.getValue(yb[k][l])+0.1)<<"\t";
                    }
                    salida<<endl;
                    
                }
            
                float vt;
                
                for (int k = 0; k < Ins.nK; k ++){
                    for (int l=0; l<Ins.nL; l++) {
                        
                  
                   
                         vt= cplex.getValue(v[k][l])*100;
                        int a = vt;
                        vt = (double)a/100;
                        
                       
                        
                       salida << floorf(cplex.getValue(v[k][l]) * 100) / 100<< "\t";
                    }
                    salida<<endl;
                }
                
                salida<<endl;
                for (j=0; j<Ins.nJ; j++){
                    for (k=0; k<Ins.nK; k++) {
                        for (l=0; l<Ins.nL; l++) {
                               cout<<(int)(cplex.getValue(u[j][k][l])+.1)<<" ";
                            salida<<(int)(cplex.getValue(u[j][k][l])+0.1)<<" ";
                        }
                        salida<<endl;
                    }
                    salida<<endl;
                }
                salida<<endl;
            
                for (l=0; l<Ins.nL; l++) {
                    for (int lp=0; lp<Ins.nL; lp++) {
                        for (k=0; k<Ins.nK; k++) {
                            
                            salida<<(int)(cplex.getValue(zK[l][lp][k])+0.1)<<"\t";
                        }
                        salida<<endl;
                    }
                    salida<<endl;
                }
                
                for (k=0; k<Ins.nK; k++) {
                    for (int kp=0; kp<Ins.nK; kp++) {
                        for (l=0; l<Ins.nL; l++) {
                            salida<<(int)(cplex.getValue(zL[k][kp][l])+0.1)<<"\t";
                        }
                        salida<<endl;
                    }
                    salida<<endl;
                }
              
                int c=0;
                ofstream salida2;
                salida2.open( "Factible.txt", ios::app );
                for (j=0; j<Ins.nJ; j++) {
                    for (k=0; k<Ins.nK; k++) {
                        for (l=0; l<Ins.nL; l++) {
                            if ((int)(cplex.getValue(u[j][k][l])+0.1)!=Ins.x[j][k][l])
                                c=c+1;
                            
                        }
                    }
                }
                if (c>0) {
                    salida2 << nombreIns << "\t No es factible "<<endl;
                }else{
                    salida2 << nombreIns << "\t Si es factible "<<endl;
                }
                salida2.close();
            
        }
        catch(IloException& e){
            cerr  << " ERROR: " << e << endl;
        }
        catch(...){
            cerr  << " ERROR" << endl;
        }
        env.end();
    
    
        return 0;
    } 
